import Cocoa

let a = 2.0, b = -6.0, c = 4.0

var x1, x2: Double
let discriminant = (b*b) - 4 * a * c //pow не работет!?... Решение : файл был открыт под ios и не был импортирован cocoa

//if discriminant > 0 {
    x1 = (-b + sqrt(discriminant)) / (2 * a)
    x2 = (-b - sqrt(discriminant)) / (2 * a)
print("Задача - 1:")
print("x1 = \(x1)\nx2 = \(x2)")
//}
//else if discriminant == 0 {
//    x1 = -b / (2 * a)
//    print ("x1,x2 = \(x1)")
//} else {
//    print("Решения нет")
//}


//
//let sideA || a = 2
//let sqA = pow(a, 2)
//let sideB || b = 4
//let sqB = pow(b, 2)
//let sideC || c = sqrt(sqA+sqB)
//let triangleSquare = (sideA * sideB) / 2
//print(triangleSquare)
//
//let hypotenuse =

let sideA = 2.0, sideB = 4.0
let sideC = sqrt(pow(sideA, 2) + sideB * sideB)
let perimetre = sideA + sideB + sideC
let square = (sideA + sideB) / 2


print("Задача - 2:")
print ("Гипотенуза = \(sideC)")
print ("Периметр = \(perimetre)")
print("Площадь = \(square)")


//let iznachSumma = 10_000
//let godStavka = 5
//let periodVGod = 1
//let srok = 5
//
//
//let finalAmount = iznachSumma*(1+((godStavka/100)/periodVGod)
//


var deposit = 10_000
let percent = 10.0
var years = 5

let rate = percent / 100

while years > 0 {
    years -= 1
    deposit = deposit * (1 + rate)
}

for _ in 1...years {
    deposit = deposit * (1 + rate)
}

deposit = deposit * pow(1 + rate, double(years)) //  не компилятся POW и Round

"Deposite = \(round (deposit * 100) / 100) рублей"

String (format: "%.2f", deposit)

